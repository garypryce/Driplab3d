import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const shoes=[
 {name:'Jordan 4',desc:'Purple Ice',price:12500,icon:'👟',shape:'chunky'},
 {name:'Air Force 1',desc:'Triple White',price:11500,icon:'👟',shape:'low'},
 {name:'Dunk Low',desc:'University Red',price:10500,icon:'👟',shape:'low'},
 {name:'Yeezy 700',desc:'Wave Runner',price:16000,icon:'👟',shape:'chunky'},
 {name:'New Balance 9060',desc:'Rain Cloud',price:15500,icon:'👟',shape:'chunky'},
 {name:'Air Max 95',desc:'Neon',price:14000,icon:'👟',shape:'chunky'}
];
const tops=[
 {name:'Oversized hoodie',desc:'Heavy fleece',price:6800,icon:'🧥',type:'hoodie'},
 {name:'Boxy graphic tee',desc:'Relaxed fit',price:3200,icon:'👕',type:'tee'},
 {name:'Puffer jacket',desc:'Layered look',price:9500,icon:'🧥',type:'puffer'},
 {name:'Varsity jacket',desc:'Classic sporty',price:8500,icon:'🥼',type:'varsity'}
];
const bottoms=[
 {name:'Baggy cargos',desc:'Utility pockets',price:7500,icon:'👖',type:'cargo'},
 {name:'Wide-leg denim',desc:'Washed black',price:6200,icon:'👖',type:'denim'},
 {name:'Track pants',desc:'Sport mode',price:4800,icon:'👖',type:'track'},
 {name:'Shorts',desc:'Summer fit',price:3500,icon:'🩳',type:'shorts'}
];
const accessories=[
 {name:'Crossbody + chain',desc:'Silver details',price:4200,icon:'🎒',type:'both'},
 {name:'Silver chain',desc:'Minimal shine',price:1800,icon:'⛓️',type:'chain'},
 {name:'Crossbody bag',desc:'Utility staple',price:2800,icon:'🎒',type:'bag'},
 {name:'No accessories',desc:'Keep it clean',price:0,icon:'✦',type:'none'}
];
const colors=[
 {name:'Purple Ice',hex:0x783de0,shoe:0x8f70d8,accent:0xc7b8ff},
 {name:'Triple Black',hex:0x242638,shoe:0x191b25,accent:0x777c95},
 {name:'University Red',hex:0xb51f36,shoe:0xc52b39,accent:0xffa3ad},
 {name:'Ocean Blue',hex:0x145a9c,shoe:0x477fb6,accent:0x9bd5ff},
 {name:'Cream Luxury',hex:0xc4b49b,shoe:0xe0d4bd,accent:0xffefd0},
 {name:'Volt Green',hex:0x81a91d,shoe:0x9abf29,accent:0xdfff76}
];
const vibes=['Streetwear classic','Clean & minimal','Bold & loud','Chill & relaxed','Luxury vibes'];
let state={shoe:0,top:0,bottom:0,acc:0,color:0,vibe:0,budget:15000,tab:'shoes',saved:false};
const $=id=>document.getElementById(id), money=n=>'JMD '+Math.round(n).toLocaleString('en-US');
function makeOptions(id,list,key,selected,onPick){$(id).innerHTML='';list.forEach((v,i)=>{let b=document.createElement('button');b.className='opt'+(i===selected?' active':'');b.textContent=typeof v==='string'?v:v.name;b.onclick=()=>onPick(i);$(id).appendChild(b)})}
function makeSwatches(){ $('swatches').innerHTML='';colors.forEach((c,i)=>{let b=document.createElement('button');b.className='swatch'+(i===state.color?' active':'');b.style.background=`linear-gradient(135deg,#${c.hex.toString(16).padStart(6,'0')},#${c.accent.toString(16).padStart(6,'0')})`;b.title=c.name;b.onclick=()=>{state.color=i;update()};$('swatches').appendChild(b)})}
function catalog(){
 const list=state.tab==='shoes'?shoes:state.tab==='tops'?tops:state.tab==='bottoms'?bottoms:accessories;
 const key=state.tab==='shoes'?'shoe':state.tab==='tops'?'top':state.tab==='bottoms'?'bottom':'acc';
 $('catalogLabel').textContent=state.tab.toUpperCase();
 $('cards').innerHTML='';
 list.forEach((item,i)=>{let b=document.createElement('button');b.className='item-card'+(state[key]===i?' active':'');b.innerHTML=`<div class="item-icon">${item.icon}</div><div class="item-name">${item.name}</div><div class="item-desc">${item.desc}</div><div class="item-price">${item.price?money(item.price):'Free'}</div>`;b.onclick=()=>{state[key]=i;update()};$('cards').appendChild(b)});
 document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===state.tab));
}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab;catalog()});
$('budgetSlider').oninput=e=>{state.budget=+e.target.value;update()};

let scene,camera,renderer,controls,avatarGroup,materials={};const canvas=$('view3d');
function mat(color,rough=.72,metal=0){return new THREE.MeshStandardMaterial({color,roughness:rough,metalness:metal})}
function mesh(geo,material,parent,x,y,z,sx=1,sy=1,sz=1){let m=new THREE.Mesh(geo,material);m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=false;m.receiveShadow=false;parent.add(m);return m}
function box(parent,x,y,z,sx,sy,sz,material,round=false){return mesh(new THREE.BoxGeometry(sx,sy,sz),material,parent,x,y,z)}
function cyl(parent,x,y,z,r1,r2,h,material){return mesh(new THREE.CylinderGeometry(r1,r2,h,16),material,parent,x,y,z)}
function makeAvatar(){
 avatarGroup=new THREE.Group();scene.add(avatarGroup);
 const skin=mat(0x8e5a3d), hair=mat(0x17131c), black=mat(0x171923), seam=mat(0x303447), white=mat(0xf3efff), sole=mat(0xe6e4f3), metal=mat(0xc5d0e8,.25,.8);
 // head, neck, ears
 mesh(new THREE.SphereGeometry(.29,16,12),skin,avatarGroup,0,3.65,0, .86,1.12,.82);
 cyl(avatarGroup,0,3.34,0,.11,.12,.22,skin);
 // textured curly hair as a cap and curls
 mesh(new THREE.SphereGeometry(.3,14,10),hair,avatarGroup,0,3.86,-.01,1.02,.7,.93);
 for(let i=0;i<34;i++){let a=i*2.399,r=.23*Math.sqrt((i%17)/17);mesh(new THREE.SphereGeometry(.065,6,5),hair,avatarGroup,Math.cos(a)*r,3.91+(i%3)*.025,Math.sin(a)*r-.01,.9,1,.9)}
 // sunglasses
 box(avatarGroup,-.115,3.68,.24,.17,.075,.035,black);box(avatarGroup,.115,3.68,.24,.17,.075,.035,black);box(avatarGroup,0,3.69,.245,.07,.025,.025,metal);
 // torso hoodie, broad shoulders
 const torsoMat=mat(colors[state.color].hex,.82);
 materials.torso=torsoMat;
 mesh(new THREE.CapsuleGeometry(.43,.75,3,7),torsoMat,avatarGroup,0,2.78,0,1.14,1.0,.7);
 // hood behind head
 mesh(new THREE.TorusGeometry(.23,.105,6,12),torsoMat,avatarGroup,0,3.38,-.11,1,1.2,.7);
 // hood strings
 for(let x of [-.09,.09]){let s=mesh(new THREE.CylinderGeometry(.009,.009,.35,8),white,avatarGroup,x,2.77,.27);s.rotation.z=x*1.5}
 // arms sleeves slant outward
 const armGeo=new THREE.CapsuleGeometry(.14,.65,3,6);
 let arm1=mesh(armGeo,torsoMat,avatarGroup,-.53,2.78,0,1,1,.95);arm1.rotation.z=-.18;
 let arm2=mesh(armGeo,torsoMat,avatarGroup,.53,2.78,0,1,1,.95);arm2.rotation.z=.18;
 mesh(new THREE.SphereGeometry(.13,8,6),skin,avatarGroup,-.58,2.35,.04);
 mesh(new THREE.SphereGeometry(.13,8,6),skin,avatarGroup,.58,2.35,.04);
 // white undershirt hem
 box(avatarGroup,0,2.24,.015,.78,.12,.48,white);
 // legs baggy trousers
 const pant=mat(state.bottom===1?0x25242a:state.bottom===2?0x252c3c:0x22232b,.95);materials.pant=pant;
 const legGeo=new THREE.CapsuleGeometry(.22,.86,3,6);
 let l=mesh(legGeo,pant,avatarGroup,-.235,1.28,0,1.15,1.08,1.08);l.rotation.z=-.025;
 let r=mesh(legGeo,pant,avatarGroup,.235,1.28,0,1.15,1.08,1.08);r.rotation.z=.025;
 // cargo pockets / seams
 if(state.bottom===0){box(avatarGroup,-.42,1.36,.19,.15,.3,.07,seam);box(avatarGroup,.42,1.36,.19,.15,.3,.07,seam);box(avatarGroup,-.42,1.36,.23,.11,.02,.015,metal);box(avatarGroup,.42,1.36,.23,.11,.02,.015,metal)}
 if(state.bottom===3){l.scale.y=.52;r.scale.y=.52;l.position.y=1.45;r.position.y=1.45}
 // ankles
 // shoes with toe pointing forward (towards camera)
 const shoeMat=mat(colors[state.color].shoe,.35,.08), accent=mat(colors[state.color].accent,.35,.08);materials.shoe=shoeMat;materials.accent=accent;
 for(let x of [-.24,.24]){
  const sh= new THREE.Group();sh.position.set(x,.32,.12);avatarGroup.add(sh);
  mesh(new THREE.BoxGeometry(.34,.18,.55),shoeMat,sh,0,0,0,1,1,1);
  mesh(new THREE.BoxGeometry(.35,.07,.56),sole,sh,0,-.09,0);
  mesh(new THREE.BoxGeometry(.31,.12,.24),accent,sh,0,.055,.13);
  if(shoes[state.shoe].shape==='chunky')mesh(new THREE.BoxGeometry(.37,.1,.58),white,sh,0,-.02,-.005);
  for(let k=0;k<3;k++){let lace=mesh(new THREE.CylinderGeometry(.008,.008,.15,6),white,sh,0,.1,.12-k*.055);lace.rotation.z=Math.PI/2}
  mesh(new THREE.BoxGeometry(.03,.08,.17),accent,sh,0,.02,-.19);
 }
 // chain necklace arcs
 if(state.acc===0||state.acc===1){let chain=mesh(new THREE.TorusGeometry(.21,.025,5,16),metal,avatarGroup,0,3.14,.22,1,.6,1);chain.rotation.x=.2}
 // crossbody strap and bag
 if(state.acc===0||state.acc===2){
  let strap=mesh(new THREE.CylinderGeometry(.035,.035,1.65,8),black,avatarGroup,.05,2.83,.25);strap.rotation.z=-.42;
  let bag=mesh(new THREE.BoxGeometry(.34,.3,.16),black,avatarGroup,.27,2.37,.3);bag.rotation.z=-.15;
  box(avatarGroup,.27,2.39,.39,.19,.025,.012,metal);
 }
 // outfit-specific top shape accents
 if(state.top===1){ // tee short sleeves
  torsoMat.color.setHex(colors[state.color].hex);arm1.scale.set(.85,.6,.85);arm2.scale.set(.85,.6,.85);
 }else if(state.top===2){torsoMat.color.setHex(0x24283b);box(avatarGroup,0,2.82,.27,.45,.45,.05,black)}
 else if(state.top===3){torsoMat.color.setHex(colors[state.color].hex);box(avatarGroup,0,2.75,.28,.08,.75,.04,white)}
}
function init3d(){
 scene=new THREE.Scene();scene.background=new THREE.Color(0x111326);scene.fog=new THREE.Fog(0x111326,8,17);
 camera=new THREE.PerspectiveCamera(36,1,.1,100);camera.position.set(0,2.7,8.8);
 renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false});renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.25));renderer.shadowMap.enabled=false;renderer.outputColorSpace=THREE.SRGBColorSpace;
 controls=new OrbitControls(camera,canvas);controls.enableDamping=true;controls.target.set(0,2.05,0);controls.minDistance=5.7;controls.maxDistance=11;controls.maxPolarAngle=Math.PI*.49;controls.minPolarAngle=Math.PI*.2;
 scene.add(new THREE.HemisphereLight(0xc9c8ff,0x241b39,2.1));
 const key=new THREE.DirectionalLight(0xffe4d0,3);key.position.set(3,7,5);key.castShadow=false;scene.add(key);
 const rim=new THREE.PointLight(0xa855f7,22,10);rim.position.set(-3,3,1);scene.add(rim);
 const blue=new THREE.PointLight(0x416bff,14,10);blue.position.set(3,2,-2);scene.add(blue);
 const floor=mesh(new THREE.CircleGeometry(5,32),mat(0x17172a,.85),scene,0,.02,0);floor.rotation.x=-Math.PI/2;
 const grid=new THREE.GridHelper(10,16,0x6f4ba7,0x302b4a);grid.position.y=.035;scene.add(grid);
 // floating neon ring behind avatar
 const ring=mesh(new THREE.TorusGeometry(1.75,.018,5,48),mat(0x7045a8,.3,.3),scene,0,2.1,-1.1);ring.rotation.x=.12;
 makeAvatar();resize();animate();
}
function resize(){let w=canvas.clientWidth,h=canvas.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}
function animate(){requestAnimationFrame(animate);controls.update();renderer.render(scene,camera)}
window.addEventListener('resize',resize);
function rebuild(){scene.remove(avatarGroup);makeAvatar()}
function update(){
 makeOptions('shoeOptions',shoes,'shoe',state.shoe,i=>{state.shoe=i;update()});
 makeOptions('topOptions',tops,'top',state.top,i=>{state.top=i;update()});
 makeOptions('bottomOptions',bottoms,'bottom',state.bottom,i=>{state.bottom=i;update()});
 makeOptions('accOptions',accessories,'acc',state.acc,i=>{state.acc=i;update()});
 makeOptions('vibeOptions',vibes,'vibe',state.vibe,i=>{state.vibe=i;update()});
 makeSwatches();
 $('shoeLabel').textContent=shoes[state.shoe].name;$('colorLabel').textContent=colors[state.color].name;$('topLabel').textContent=tops[state.top].name;$('bottomLabel').textContent=bottoms[state.bottom].name;$('accLabel').textContent=accessories[state.acc].name;
 $('wallet').textContent=state.budget.toLocaleString('en-US');$('budgetValue').textContent=money(state.budget);
 $('fitTitle').textContent=colors[state.color].name+' • '+vibes[state.vibe];$('shoeChip').textContent=shoes[state.shoe].name;$('topChip').textContent=tops[state.top].name;$('vibeChip').textContent=vibes[state.vibe];
 const total=shoes[state.shoe].price+tops[state.top].price+bottoms[state.bottom].price+accessories[state.acc].price;
 $('shoePrice').textContent=money(shoes[state.shoe].price);$('topPrice').textContent=money(tops[state.top].price);$('bottomPrice').textContent=money(bottoms[state.bottom].price);$('accPrice').textContent=money(accessories[state.acc].price);$('totalPrice').textContent=money(total);
 $('totalPrice').style.color=total<=state.budget?'#72efad':'#ff8caa';
 let score=84+(state.color===0?4:0)+(state.acc===0?3:0)+(state.bottom===0?3:0)+(state.top===0?2:0)-(total>state.budget?8:0);
 if(state.vibe===1&&state.color===1)score+=3;if(state.vibe===2&&state.color===2)score+=3;score=Math.max(55,Math.min(99,score));
 $('score').textContent=score;$('scoreCircle').style.background=`conic-gradient(#a855f7 0 ${score}%,#2c2f4d ${score}% 100%)`;
 $('scoreWord').textContent=score>93?'HEAT CHECK 🔥':score>85?'SOLID FIT':'ROOM TO LEVEL UP';
 $('scoreNote').textContent=total>state.budget?'Over budget — swap one piece for a cheaper option.':score>90?'The colours and silhouette are working together. This fit is ready to go.':'Try a matching colour accent or one statement accessory.';
 $('barShoe').style.width=(72+state.shoe*3)+'%';$('barTop').style.width=(75+state.top*4)+'%';$('barBottom').style.width=(72+state.bottom*4)+'%';$('barAcc').style.width=(60+state.acc*10)+'%';
 if(scene&&avatarGroup)rebuild();catalog();
}
$('suggestBtn').onclick=()=>{
 const affordableShoes=shoes.map((x,i)=>({x,i})).filter(o=>o.x.price+tops[state.top].price+bottoms[state.bottom].price+accessories[state.acc].price<=state.budget);
 if(affordableShoes.length){state.shoe=affordableShoes[Math.floor(Math.random()*affordableShoes.length)].i}
 else {state.shoe=1;state.top=1;state.bottom=2;state.acc=3;state.color=1}
 if(state.vibe===0)state.color=0;else if(state.vibe===1)state.color=1;else if(state.vibe===2)state.color=2;else if(state.vibe===3)state.color=3;else state.color=4;
 update();
};
$('saveBtn').onclick=()=>{let outfit={shoe:state.shoe,top:state.top,bottom:state.bottom,acc:state.acc,color:state.color,vibe:state.vibe};try{localStorage.setItem('dripLabSaved',JSON.stringify(outfit));$('saveBtn').textContent='✓ Look saved';$('saveBtn').style.borderColor='#72efad'}catch(e){$('saveBtn').textContent='Look ready!'}};
try{const saved=JSON.parse(localStorage.getItem('dripLabSaved')||'null');if(saved)state={...state,...saved}}catch(e){}
init3d();update();
