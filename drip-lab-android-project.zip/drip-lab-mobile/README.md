# DRIP LAB — Android mobile app starter

This packages the uploaded DRIP LAB 3D Outfit Simulator as an Android app using Capacitor. The Three.js renderer is bundled locally rather than loaded from a CDN, so the 3D library itself does not need an internet connection after installation.

## Build an APK (Windows, macOS, or Linux)

Requirements: Node.js LTS, Android Studio, and an Android SDK installed through Android Studio.

1. Extract this ZIP.
2. Open a terminal in the extracted `drip-lab-mobile` folder.
3. Run:

   ```sh
   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
   ```

4. In Android Studio, wait for Gradle sync to finish.
5. For a test build, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Install the generated debug APK on your Android device. To distribute it, create a signed APK or AAB from **Build → Generate Signed Bundle / APK**.

If the `android` folder already exists, skip `npx cap add android` and run `npx cap sync android` instead.

## Quick browser preview

```sh
npm install
npm run dev
```

Open the local address printed by Vite. The browser preview needs WebGL support. The Android build bundles Three.js locally; no server is required to render the game after installation.

## Notes

- The game uses a lightweight procedural 3D avatar, orbit/touch rotation, outfit controls, JMD pricing, and browser local storage for the saved look.
- Saving outfits uses local storage inside the app's WebView.
- This ZIP is the Android project starter, not a precompiled APK. Android Studio/Gradle must compile the APK on a computer.
- JavaScript inside any client-side app cannot be made truly secret by encryption; production builds can be minified, but code running on the device can still be inspected.
